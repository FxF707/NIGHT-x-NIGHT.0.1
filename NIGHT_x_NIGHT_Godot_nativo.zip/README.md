# NIGHT x NIGHT — Projeto Godot nativo (sem HTML)

Este projeto usa **Godot 4.x + GDScript**, com renderização 2D nativa. Não é um site nem um jogo HTML.

## Testar
1. Baixe e extraia o ZIP.
2. Em um computador, instale Godot 4.3 ou superior.
3. No Godot, importe o arquivo `project.godot` e pressione Play.

## Android / APK
O projeto já está estruturado para exportação Android, com orientação horizontal e controles de toque.
Para exportar um APK, o Godot precisa dos Android build templates, Android SDK, JDK e configuração de exportação Android. O APK não está incluído neste ZIP: precisa ser compilado.

### Exportar
1. Instale Godot 4.x e os Export Templates da mesma versão.
2. Configure Android SDK/JDK em Editor > Editor Settings > Export > Android.
3. Em Project > Export, adicione preset Android e configure package name `com.nightxnight.game`.
4. Exporte primeiro um APK de teste. Para Play Store, configure uma chave de assinatura de release e gere AAB (Android App Bundle), além de preencher as informações de privacidade e classificação.

## Observações
- Protótipo original inicial: cenário desenhado por código, movimento, salto, inimigos, ataque, vida e 10 colecionáveis.
- Ainda não é um Metroidvania completo. Próximas etapas recomendadas: animações e arte final, mapa com salas interligadas, habilidades que desbloqueiam áreas, checkpoints, chefes, áudio, menu de pausa e testes em vários celulares.
- O jogo é inspirado apenas no gênero Metroidvania sombrio; personagens, nome, cenários e elementos são próprios. Não usa assets de Hollow Knight.
