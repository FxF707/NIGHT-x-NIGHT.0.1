extends Node2D

# NIGHT x NIGHT — protótipo original. Arte desenhada no próprio Godot.
const WORLD_WIDTH := 4300.0
const FLOOR_Y := 420.0
const GRAVITY := 1500.0
const MOVE_SPEED := 300.0
const JUMP_SPEED := -600.0

var player := Vector2(100, FLOOR_Y - 48)
var velocity := Vector2.ZERO
var player_size := Vector2(30, 46)
var facing := 1
var grounded := false
var hp := 3
var echoes := 0
var attack_timer := 0.0
var invincible_timer := 0.0
var game_started := false
var dead_timer := 0.0
var camera_x := 0.0
var jump_queued := false
var attack_queued := false
var touch_left := false
var touch_right := false
var touch_jump := false
var touch_attack := false
var collected: Array[bool] = []
var enemies: Array[Dictionary] = []
var platforms: Array[Rect2] = []
var particles: Array[Dictionary] = []
var world_time := 0.0
var message := "Explore as ruínas e encontre os Ecos azuis"

const GEM_X := [440.0, 690.0, 1010.0, 1280.0, 1740.0, 2050.0, 2540.0, 3210.0, 3650.0, 4050.0]
const GEM_Y := [330.0, 265.0, 320.0, 235.0, 305.0, 230.0, 300.0, 280.0, 325.0, 260.0]
const GROUND_SEGMENTS := [[0.0, 850.0], [950.0, 1570.0], [1680.0, 2370.0], [2480.0, 3150.0], [3260.0, 4300.0]]

func _ready() -> void:
	for i in GEM_X.size():
		collected.append(false)
	platforms = [
		Rect2(250, 325, 150, 18), Rect2(550, 265, 150, 18),
		Rect2(1010, 315, 140, 18), Rect2(1210, 230, 170, 18),
		Rect2(1710, 305, 180, 18), Rect2(1980, 225, 160, 18),
		Rect2(2530, 300, 180, 18), Rect2(2820, 230, 160, 18),
		Rect2(3350, 300, 160, 18), Rect2(3600, 250, 170, 18),
		Rect2(3910, 320, 150, 18)
	]
	enemies = [
		{"x": 610.0, "base": 610.0, "dir": 1.0, "hp": 2, "range": 80.0},
		{"x": 1110.0, "base": 1110.0, "dir": -1.0, "hp": 2, "range": 90.0},
		{"x": 1850.0, "base": 1850.0, "dir": 1.0, "hp": 3, "range": 100.0},
		{"x": 2700.0, "base": 2700.0, "dir": -1.0, "hp": 3, "range": 100.0},
		{"x": 3510.0, "base": 3510.0, "dir": 1.0, "hp": 3, "range": 100.0}
	]
	queue_redraw()

func _process(delta: float) -> void:
	world_time += delta
	if not game_started:
		queue_redraw()
		return
	if dead_timer > 0.0:
		dead_timer -= delta
		if dead_timer <= 0.0:
			_respawn()
		queue_redraw()
		return
	_update_player(delta)
	_update_enemies(delta)
	_update_particles(delta)
	camera_x = clamp(player.x - 350.0, 0.0, WORLD_WIDTH - 960.0)
	queue_redraw()

func _update_player(delta: float) -> void:
	var axis := float(touch_right or Input.is_action_pressed("ui_right")) - float(touch_left or Input.is_action_pressed("ui_left"))
	if axis != 0.0:
		facing = int(sign(axis))
	velocity.x = axis * MOVE_SPEED
	if jump_queued or touch_jump or Input.is_action_just_pressed("ui_accept"):
		if grounded:
			velocity.y = JUMP_SPEED
			grounded = false
	jump_queued = false
	velocity.y = min(velocity.y + GRAVITY * delta, 900.0)
	var old_y := player.y
	player.x = clamp(player.x + velocity.x * delta, 0.0, WORLD_WIDTH - player_size.x)
	player.y += velocity.y * delta
	grounded = false
	if velocity.y >= 0.0:
		for seg in GROUND_SEGMENTS:
			var left: float = seg[0]
			var right: float = seg[1]
			if player.x + player_size.x > left and player.x < right and old_y + player_size.y <= FLOOR_Y and player.y + player_size.y >= FLOOR_Y:
				player.y = FLOOR_Y - player_size.y
				velocity.y = 0.0
				grounded = true
		for p in platforms:
			if player.x + player_size.x > p.position.x and player.x < p.end.x and old_y + player_size.y <= p.position.y and player.y + player_size.y >= p.position.y:
				player.y = p.position.y - player_size.y
				velocity.y = 0.0
				grounded = true
	if player.y > 700.0:
		hp -= 1
		dead_timer = 0.65
	if attack_queued or touch_attack or Input.is_action_just_pressed("ui_select"):
		attack_timer = 0.22
		for i in enemies.size():
			var e: Dictionary = enemies[i]
			if int(e["hp"]) > 0 and abs(player.x + player_size.x * 0.5 - float(e["x"])) < 88.0 and abs(player.y + player_size.y - FLOOR_Y) < 95.0:
				e["hp"] = int(e["hp"]) - 1
				enemies[i] = e
				_spawn_sparks(Vector2(float(e["x"]), FLOOR_Y - 26), Color(0.4, 1.0, 0.84), 8)
	attack_queued = false
	attack_timer = max(0.0, attack_timer - delta)
	invincible_timer = max(0.0, invincible_timer - delta)
	for i in GEM_X.size():
		if not collected[i] and player.distance_to(Vector2(GEM_X[i], GEM_Y[i])) < 48.0:
			collected[i] = true
			echoes += 1
			_spawn_sparks(Vector2(GEM_X[i], GEM_Y[i]), Color(0.45, 0.88, 1.0), 15)
	if echoes == GEM_X.size():
		message = "Todos os Ecos encontrados. O Vale se lembra de você."

func _update_enemies(delta: float) -> void:
	for i in enemies.size():
		var e: Dictionary = enemies[i]
		if int(e["hp"]) <= 0:
			continue
		e["x"] = float(e["x"]) + float(e["dir"]) * 52.0 * delta
		if abs(float(e["x"]) - float(e["base"])) > float(e["range"]):
			e["dir"] = -float(e["dir"])
		if invincible_timer <= 0.0 and abs(player.x + 15.0 - float(e["x"])) < 30.0 and abs(player.y + player_size.y - FLOOR_Y) < 50.0:
			hp -= 1
			invincible_timer = 1.2
			velocity.y = -240.0
			_spawn_sparks(player + Vector2(15, 25), Color(1.0, 0.36, 0.48), 10)
			if hp <= 0:
				dead_timer = 0.7
		enemies[i] = e

func _update_particles(delta: float) -> void:
	for i in range(particles.size() - 1, -1, -1):
		particles[i]["life"] = float(particles[i]["life"]) - delta
		particles[i]["pos"] = particles[i]["pos"] + particles[i]["vel"] * delta
		particles[i]["vel"] = particles[i]["vel"] * 0.94
		if float(particles[i]["life"]) <= 0.0:
			particles.remove_at(i)

func _spawn_sparks(pos: Vector2, color: Color, amount: int) -> void:
	for i in amount:
		var angle := randf() * TAU
		particles.append({"pos": pos, "vel": Vector2(cos(angle), sin(angle)) * randf_range(35, 150), "life": randf_range(0.25, 0.65), "color": color})

func _respawn() -> void:
	if hp <= 0:
		hp = 3
	player = Vector2(max(80.0, floor(player.x / 850.0) * 850.0 + 50.0), FLOOR_Y - player_size.y)
	velocity = Vector2.ZERO
	invincible_timer = 1.0

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP:
			jump_queued = true
		if event.keycode == KEY_X or event.keycode == KEY_J:
			attack_queued = true
	if event is InputEventScreenTouch:
		if event.pressed:
			var p := event.position
			if not game_started:
				game_started = true
			elif p.y > 370.0:
				if p.x < 200.0:
					touch_left = true
				elif p.x < 330.0:
					touch_right = true
				elif p.x > 790.0:
					touch_jump = true
				elif p.x > 620.0:
					touch_attack = true
		else:
			touch_left = false
			touch_right = false
			touch_jump = false
			touch_attack = false

func _draw() -> void:
	var size := get_viewport_rect().size
	_draw_background(size)
	if not game_started:
		_draw_title(size)
		return
	_draw_world(size)
	_draw_player()
	_draw_hud(size)
	_draw_controls(size)
	if dead_timer > 0.0:
		draw_rect(Rect2(0, 0, size.x, size.y), Color(0.02, 0.03, 0.06, 0.55))
		draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 95, size.y * 0.5), "O VALE TE REJEITA", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.9, 0.72, 0.78))

func _draw_background(size: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#080d1b"))
	draw_circle(Vector2(size.x * 0.78, size.y * 0.24), 180, Color(0.06, 0.32, 0.38, 0.14))
	for layer in 3:
		var points := PackedVector2Array()
		points.append(Vector2(0, size.y))
		for x in range(-80, int(size.x) + 100, 80):
			var wx := float(x) + camera_x * (0.12 + layer * 0.13)
			var y := size.y * (0.49 + layer * 0.09) + sin(wx * 0.006 + layer * 2.0) * 32.0 + sin(wx * 0.017) * 15.0
			points.append(Vector2(x, y))
		points.append(Vector2(size.x, size.y))
		draw_colored_polygon(points, [Color("#101d2b"), Color("#0c1823"), Color("#0a141c")][layer])
	for i in 55:
		var x := fposmod(i * 137.0 - camera_x * 0.25, size.x)
		var y := fposmod(i * 71.0 + sin(world_time * 1.7 + i) * 12.0, size.y * 0.7)
		draw_circle(Vector2(x, y), 1.4, Color(0.55, 0.88, 0.86, 0.24))

func _draw_world(size: Vector2) -> void:
	for seg in GROUND_SEGMENTS:
		var x := float(seg[0]) - camera_x
		var w := float(seg[1]) - float(seg[0])
		if x + w < 0 or x > size.x:
			continue
		draw_rect(Rect2(x, FLOOR_Y, w, size.y - FLOOR_Y + 100), Color("#111c23"))
		draw_rect(Rect2(x, FLOOR_Y, w, 6), Color("#4b998f"))
		draw_rect(Rect2(x, FLOOR_Y + 6, w, 3), Color("#243e45"))
		for xx in range(int(float(seg[0])), int(float(seg[1])), 38):
			draw_rect(Rect2(xx - camera_x, FLOOR_Y + 20, 17, 2), Color("#24343b"))
	for p in platforms:
		var r := Rect2(p.position.x - camera_x, p.position.y, p.size.x, p.size.y)
		draw_rect(r, Color("#1b2a35"))
		draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 4), Color("#5b918b"))
		for xx in range(int(r.position.x), int(r.end.x), 30):
			draw_rect(Rect2(xx, r.position.y + 8, 13, 2), Color("#35464e"))
	for x in range(130, int(WORLD_WIDTH), 230):
		var sx := x - camera_x
		if sx < -30 or sx > size.x + 30:
			continue
		draw_circle(Vector2(sx, FLOOR_Y - 20), 19, Color(0.05, 0.7, 0.54, 0.12))
		draw_line(Vector2(sx, FLOOR_Y - 2), Vector2(sx, FLOOR_Y - 18), Color("#34786c"), 3)
		draw_circle(Vector2(sx, FLOOR_Y - 21), 4, Color("#8dffe0"))
	for i in GEM_X.size():
		if collected[i]:
			continue
		var g := Vector2(GEM_X[i] - camera_x, GEM_Y[i] + sin(world_time * 2.2 + i) * 5)
		draw_circle(g, 18, Color(0.1, 0.65, 1.0, 0.13))
		var diamond := PackedVector2Array([g + Vector2(0, -11), g + Vector2(8, 0), g + Vector2(0, 11), g + Vector2(-8, 0)])
		draw_colored_polygon(diamond, Color("#9cecff"))
		draw_polyline(PackedVector2Array([diamond[0], diamond[1], diamond[2], diamond[3], diamond[0]]), Color("#efffff"), 1.5)
	for e in enemies:
		if int(e["hp"]) <= 0:
			continue
		var x := float(e["x"]) - camera_x
		if x < -60 or x > size.x + 60:
			continue
		var y := FLOOR_Y - 24
		draw_circle(Vector2(x, y), 25, Color(0.7, 0.12, 0.3, 0.12))
		draw_colored_polygon(PackedVector2Array([Vector2(x - 21, y + 8), Vector2(x - 18, y - 8), Vector2(x - 9, y - 17), Vector2(x + 12, y - 17), Vector2(x + 22, y - 3), Vector2(x + 19, y + 10), Vector2(x, y + 16)]), Color("#342536"))
		draw_rect(Rect2(x - 10, y - 5, 5, 4), Color("#ef8d99"))
		draw_rect(Rect2(x + 5, y - 5, 5, 4), Color("#ef8d99"))
		draw_rect(Rect2(x - 19, y - 31, 38, 3), Color("#311c29"))
		draw_rect(Rect2(x - 19, y - 31, 38 * float(e["hp"]) / 3.0, 3), Color("#e46d86"))
	for p in particles:
		draw_circle(p["pos"] - Vector2(camera_x, 0), 3, p["color"] * clamp(float(p["life"]) * 2.0, 0.0, 1.0))
	for i in range(4):
		var gx := [900.0, 1620.0, 2420.0, 3200.0][i] - camera_x
		if gx < -50 or gx > size.x + 50:
			continue
		draw_arc(Vector2(gx, FLOOR_Y - 52), 24, 0, TAU, 32, Color(0.3, 0.92, 0.8, 0.85), 3)
		draw_arc(Vector2(gx, FLOOR_Y - 52), 17, 0, TAU, 32, Color(0.3, 0.92, 0.8, 0.35), 1)

func _draw_player() -> void:
	if invincible_timer > 0.0 and int(world_time * 12) % 2 == 0:
		return
	var x := player.x - camera_x
	var y := player.y
	draw_circle(Vector2(x + 15, y + 30), 37, Color(0.12, 0.85, 0.69, 0.10))
	draw_colored_polygon(PackedVector2Array([Vector2(x + 4, y + 15), Vector2(x + 26, y + 15), Vector2(x + 32, y + 43), Vector2(x + 16, y + 37), Vector2(x, y + 43)]), Color("#111a25"))
	draw_circle(Vector2(x + 15, y + 14), 13, Color("#dce8e5"))
	draw_colored_polygon(PackedVector2Array([Vector2(x + 5, y + 12), Vector2(x + 12, y + 15), Vector2(x + 8, y + 20)]), Color("#101c27"))
	draw_colored_polygon(PackedVector2Array([Vector2(x + 25, y + 12), Vector2(x + 18, y + 15), Vector2(x + 22, y + 20)]), Color("#101c27"))
	draw_circle(Vector2(x + 10, y + 16), 3.3, Color("#71f4d5"))
	draw_circle(Vector2(x + 21, y + 16), 3.3, Color("#71f4d5"))
	draw_line(Vector2(x + 15, y + 29), Vector2(x + 15 + facing * 20, y + 22), Color("#c5fff1"), 3)
	if attack_timer > 0.0:
		draw_arc(Vector2(x + 15 + facing * 20, y + 27), 24, -0.8 * facing, 0.8 * facing, 18, Color("#c4fff2"), 5)

func _draw_hud(size: Vector2) -> void:
	draw_string(ThemeDB.fallback_font, Vector2(18, 28), "NIGHT x NIGHT", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#e7fff9"))
	draw_string(ThemeDB.fallback_font, Vector2(19, 45), "O VALE SEM AURORA", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color("#8be5c8"))
	draw_string(ThemeDB.fallback_font, Vector2(size.x - 160, 28), "♥ ".repeat(max(0, hp)) + "♡ ".repeat(max(0, 3 - hp)), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#ff9da9"))
	draw_string(ThemeDB.fallback_font, Vector2(size.x - 160, 48), "ECOS %d / %d" % [echoes, GEM_X.size()], HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#b9eaff"))
	draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 155, 68), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.78, 0.86, 0.9, 0.85))

func _draw_controls(size: Vector2) -> void:
	_draw_button(Rect2(18, size.y - 92, 76, 70), "◀")
	_draw_button(Rect2(102, size.y - 92, 76, 70), "▶")
	_draw_button(Rect2(size.x - 182, size.y - 92, 76, 70), "GOLPE")
	_draw_button(Rect2(size.x - 98, size.y - 92, 80, 70), "PULO")

func _draw_button(r: Rect2, label: String) -> void:
	draw_rect(r, Color(0.04, 0.13, 0.18, 0.82), true, 12)
	draw_rect(r, Color(0.45, 0.9, 0.82, 0.65), false, 2, true)
	draw_string(ThemeDB.fallback_font, r.position + Vector2(12, r.size.y * 0.58), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#efffff"))

func _draw_title(size: Vector2) -> void:
	draw_circle(Vector2(size.x * 0.5, size.y * 0.37), 100, Color(0.1, 0.75, 0.65, 0.07))
	draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 190, size.y * 0.38), "NIGHT x NIGHT", HORIZONTAL_ALIGNMENT_LEFT, -1, 38, Color("#e7fff9"))
	draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 142, size.y * 0.38 + 30), "O VALE SEM AURORA", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#8be5c8"))
	draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 210, size.y * 0.55), "Toque na tela para entrar no vale", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#c1d1e0"))
	draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 170, size.y * 0.62), "Explore • Salte • Ataque • Recolha os Ecos", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#84a7b8"))
